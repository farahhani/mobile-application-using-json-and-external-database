package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class AnnouncementLocalStore
{
    public static final String SP_Ann="ann";
    SharedPreferences announcementLocalDatabase;
    public AnnouncementLocalStore(Context context)
    {
        announcementLocalDatabase=context.getSharedPreferences(SP_Ann,0);
    }
    public void storeAnnouncementData(Announcement ann)
    {
        SharedPreferences.Editor spEditor=announcementLocalDatabase.edit();
        spEditor.putString("date",ann.date);
        spEditor.putString("event",ann.event);
        spEditor.commit();
    }
    public Announcement getLoggedInAnnouncement()
    {
        String date =announcementLocalDatabase.getString("date", "");
        String event =announcementLocalDatabase.getString("event","");
        Announcement ann       =new Announcement(date,event);
        return ann;
    }
    public  void setAnnouncementLoggedIn(boolean loggedIn)
    {
        SharedPreferences.Editor spEditor=announcementLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }
    public void  clearAnnouncementData()
    {
        SharedPreferences.Editor spEditor=announcementLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }
    public boolean getAnnouncementLoggedIn()
    {
        if (announcementLocalDatabase.getBoolean("loggedIn", false)== true)
        {
            return true;
        }else{
            return false;
        }
    }
}

