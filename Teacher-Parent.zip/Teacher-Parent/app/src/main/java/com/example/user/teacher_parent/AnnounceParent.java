package com.example.user.teacher_parent;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;


public class AnnounceParent extends ActionBarActivity {

    String myJSON;

    private static final String TAG_RESULTS="result";
    private static final String TAG_PID = "pid";
    private static final String TAG_DATE = "date";
    private static final String TAG_EVENT ="event";

    JSONArray announce = null;

    ArrayList<HashMap<String, String>> announceList;

    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announce_parent);
        list = (ListView) findViewById(R.id.listView);
        announceList = new ArrayList<HashMap<String,String>>();
        getData();
    }


    protected void showList(){
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            announce = jsonObj.getJSONArray(TAG_RESULTS);

            for(int i=0;i<announce.length();i++){
                JSONObject c = announce.getJSONObject(i);
                String pid = c.getString(TAG_PID);
                String date = c.getString(TAG_DATE);
                String event = c.getString(TAG_EVENT);

                HashMap<String,String> announce = new HashMap<String,String>();

                announce.put(TAG_PID,pid);
                announce.put(TAG_DATE,date);
                announce.put(TAG_EVENT,event);

                announceList.add(announce);
            }

            ListAdapter adapter = new SimpleAdapter(
                    AnnounceParent.this, announceList, R.layout.activity_list_announce_parent,
                    new String[]{TAG_PID,TAG_DATE,TAG_EVENT},
                    new int[]{R.id.pid, R.id.date, R.id.event}
            );

            list.setAdapter(adapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void getData(){
        class GetDataJSON extends AsyncTask<String, Void, String>{

            @Override
            protected String doInBackground(String... params) {
                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://fara.16mb.com/getAnnounce.php");

                // Depends on your web service
                httppost.setHeader("Content-type", "application/json");

                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();

                    inputStream = entity.getContent();
                    // json is UTF-8 by default
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                    // Oops
                }
                finally {
                    try{if(inputStream != null)inputStream.close();}catch(Exception squish){}
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result){
                myJSON=result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }

}