package com.example.user.teacher_parent;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class WelcomeParent extends ActionBarActivity implements View.OnClickListener {

    Button bLogout, bAnnounce, bChildReport;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_parent);

        bLogout = (Button) findViewById(R.id.bLogout);
        bAnnounce = (Button) findViewById(R.id.bAnnounce);
        bChildReport = (Button) findViewById(R.id.bChildReport);


        bLogout.setOnClickListener(this);
        bAnnounce.setOnClickListener(this);
        bChildReport.setOnClickListener(this);

    }

    public void onClick(View v){

        switch (v.getId()){
            case R.id.bLogout:
                Intent loginscreen=new Intent(this,MainActivity.class);
                loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
                startActivity(loginscreen);
                this.finish();
                break;

            case R.id.bAnnounce:
                startActivity(new Intent(this, AnnounceParent.class));
                break;

            case R.id.bChildReport:
                startActivity(new Intent(this, Class.class));
                break;






        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_welcome_parent, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.list_item) {
            return true;}
        else if (id == R.id.menu_profile) {
            goToMenuProfilePage();
            return true;
        }else if (id == R.id.menu_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goToMenuProfilePage()
    {
        Intent intent = new Intent(this,Profile.class);
        startActivity(intent);
    }

    private void logout()
    {
        Intent loginscreen=new Intent(this,MainActivity.class);
        loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
        startActivity(loginscreen);
        this.finish();
    }


}
