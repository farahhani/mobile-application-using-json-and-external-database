package com.example.user.teacher_parent;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Welcome extends ActionBarActivity implements View.OnClickListener {

    Button bLogout, bAnnounce, bAdd, bClass, bRecPa;
    TeacherLocalStore teacherLocalStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        bLogout = (Button) findViewById(R.id.bLogout);
        bClass = (Button) findViewById(R.id.bClass);
        bAnnounce = (Button) findViewById(R.id.bAnnounce);
        bAdd = (Button) findViewById(R.id.bAdd);
        bRecPa = (Button) findViewById(R.id.bRecPa);

        bClass.setOnClickListener(this);
        bLogout.setOnClickListener(this);
        bAnnounce.setOnClickListener(this);
        bAdd.setOnClickListener(this);
        bRecPa.setOnClickListener(this);

        teacherLocalStore = new TeacherLocalStore(this);

    }
    @Override

    public void onClick(View v){

        switch (v.getId()){
            case R.id.bLogout:

                Intent loginscreen=new Intent(this,MainActivity.class);
                loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
                startActivity(loginscreen);
                this.finish();
                break;

            case R.id.bAnnounce:
                startActivity(new Intent(this, Announce.class));
                break;

            case R.id.bClass:
                startActivity(new Intent(this, Class.class));
                break;

            case R.id.bAdd:
                startActivity(new Intent(this, Add.class));
                break;

            case R.id.bRecPa:
                startActivity(new Intent(this, ViewParent.class));
                break;


        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_welcome, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.list_item) {
            return true;}
        else if (id == R.id.menu_profile) {
            goToMenuProfilePage();
            return true;
        }else if (id == R.id.menu_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goToMenuProfilePage()
    {
        Intent intent = new Intent(this,Profile.class);
        startActivity(intent);
    }

    private void logout()
    {
        Intent loginscreen=new Intent(this,MainActivity.class);
        loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
        startActivity(loginscreen);
        this.finish();
    }


}

