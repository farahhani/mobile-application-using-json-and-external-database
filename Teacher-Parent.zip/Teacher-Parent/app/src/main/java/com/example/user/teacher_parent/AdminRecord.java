package com.example.user.teacher_parent;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.user.teacher_parent.R;

public class AdminRecord extends ActionBarActivity implements View.OnClickListener{

    Button bRecParent, bRecStudent, bLogout;
    UserLocalStore userLocalStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_record);

        bRecParent = (Button) findViewById(R.id.bRecParent);
        bLogout = (Button) findViewById(R.id.bLogout);
        bRecStudent = (Button) findViewById(R.id.bRecStudent);

        bLogout.setOnClickListener(this);
        bRecParent.setOnClickListener(this);
        bRecStudent.setOnClickListener(this);

        userLocalStore = new UserLocalStore(this);
    }

    @Override

    public void onClick(View v){

        switch (v.getId()){
            case R.id.bLogout:
                Intent loginscreen=new Intent(this,MainActivity.class);
                loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
                startActivity(loginscreen);
                this.finish();
                break;

            case R.id.bRecParent:
                startActivity(new Intent(this, ViewParent.class));
                break;

            case R.id.bRecStudent:
                startActivity(new Intent(this, Class.class));
                break;
        }
    }

    private void logout()
    {
        Intent loginscreen=new Intent(this,MainActivity.class);
        loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
        startActivity(loginscreen);
        this.finish();
    }


}

