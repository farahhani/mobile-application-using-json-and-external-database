package com.example.user.teacher_parent;

/**
 * Created by user on 21/11/2015.
 */
public class Announcement
{
    String event, date;


    public Announcement(String event,String date)
    {
        this.date=date;
        this.event=event;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getEvent() {
        return event;
    }
    public void setEvent(String event) {
        this.event = event;
    }
}
