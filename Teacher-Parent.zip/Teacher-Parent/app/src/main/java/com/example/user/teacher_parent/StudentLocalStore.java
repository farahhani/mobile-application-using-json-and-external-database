package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class StudentLocalStore
{
    public static final String SP_Student="student";
    SharedPreferences studentLocalDatabase;
    public StudentLocalStore(Context context)
    {
        studentLocalDatabase=context.getSharedPreferences(SP_Student,0);
    }
    public void storeStudentData(Student student)
    {
        SharedPreferences.Editor spEditor=studentLocalDatabase.edit();
        spEditor.putString("name", student.name);
        spEditor.putString("ic", student.ic);
        spEditor.putString("cls",student.cls);
        spEditor.commit();
    }
    public Student getLoggedInStudent()
    {
        String name     =studentLocalDatabase.getString("name", "");
        String ic         =studentLocalDatabase.getString("ic", "");
        String cls =studentLocalDatabase.getString("cls", "");
        String mark =studentLocalDatabase.getString("mark", "");
        String comment =studentLocalDatabase.getString("comment", "");

        Student student       =new Student(name,ic,cls,mark,comment);
        return student;
    }
    public  void setStudentLoggedIn(boolean loggedIn)
    {
        SharedPreferences.Editor spEditor=studentLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }
    public void  clearStudentData()
    {
        SharedPreferences.Editor spEditor=studentLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }
    public boolean getStudentLoggedIn()
    {
        if (studentLocalDatabase.getBoolean("loggedIn", false)== true)
        {
            return true;
        }else{
            return false;
        }
    }
}

