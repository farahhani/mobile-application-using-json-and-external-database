package com.example.user.teacher_parent;

/**
 * Created by user on 20/11/2015.
 */
interface GetParentCallback
{
    public abstract void done(Parent parent);
}
