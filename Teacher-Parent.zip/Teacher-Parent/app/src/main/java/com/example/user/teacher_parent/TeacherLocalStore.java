package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class TeacherLocalStore
{
    public static final String SP_Teacher="teacher";
    SharedPreferences teacherLocalDatabase;
    public TeacherLocalStore(Context context)
    {
        teacherLocalDatabase=context.getSharedPreferences(SP_Teacher,0);
    }
    public void storeTeacherData(Teacher teacher)
    {
        SharedPreferences.Editor spEditor=teacherLocalDatabase.edit();
        spEditor.putString("name",teacher.name);
        spEditor.putString("ic", teacher.ic);
        spEditor.putString("username",teacher.username);
        spEditor.putString("password",teacher.password);
        spEditor.commit();
    }
    public Teacher getLoggedInTeacher()
    {
        String name     =teacherLocalDatabase.getString("name", "");
        String ic         =teacherLocalDatabase.getString("ic", "");
        String username =teacherLocalDatabase.getString("username", "");
        String password =teacherLocalDatabase.getString("password","");
        Teacher teacher       =new Teacher(name,ic,username,password);
        return teacher;
    }
    public  void setTeacherLoggedIn(boolean loggedIn)
    {
        SharedPreferences.Editor spEditor=teacherLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }
    public void  clearTeacherData()
    {
        SharedPreferences.Editor spEditor=teacherLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }
    public boolean getTeacherLoggedIn()
    {
        if (teacherLocalDatabase.getBoolean("loggedIn", false)== true)
        {
            return true;
        }else{
            return false;
        }
    }
}

