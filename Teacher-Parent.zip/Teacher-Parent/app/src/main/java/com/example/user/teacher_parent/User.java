package com.example.user.teacher_parent;

/**
 * Created by user on 1/11/2015.
 */
public class User
{
    String name,ic,username,password;


    public User(String name,String ic,String username,String password)
    {
        this.name=name;
        this.ic=ic;
        this.username=username;
        this.password=password;
    }
    public User(String username,String password)
    {
        this.name="";
        this.ic="";
        this.username=username;
        this.password=password;
    }
}
