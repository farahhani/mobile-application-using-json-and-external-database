
package com.example.user.teacher_parent;

/**
 * Created by user on 1/11/2015.
 */
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;


public class ServerRequestTeacher
{
    ProgressDialog progressDialog;
    public ServerRequestTeacher(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setTitle("Processing");
        progressDialog.setMessage("Please wait....");
        System.out.println("--------------------------");
    }

    public void storeTeacherDataInBackground(Teacher teacher, GetTeacherCallback teacherCallback)
    {
        progressDialog.show();
        new StoreTeacherDataAsyncTack(teacher,teacherCallback).execute();
    }
    public class StoreTeacherDataAsyncTack extends AsyncTask<Void,Void,Void>
    {
        Teacher teacher;
        GetTeacherCallback teacherCallback;
        public  StoreTeacherDataAsyncTack(Teacher teacher,GetTeacherCallback teacherCallback)
        {
            this.teacher=teacher;
            this.teacherCallback= teacherCallback;
        }

        @Override
        protected Void doInBackground(Void... params)
        {
            ArrayList<NameValuePair> param=new ArrayList<>();
            param.add(new BasicNameValuePair("name",teacher.name));
            param.add(new BasicNameValuePair("ic",teacher.ic));
            param.add(new BasicNameValuePair("username",teacher.username));
            param.add(new BasicNameValuePair("password", teacher.password));
            try {
                URL url = new URL("http://fara.16mb.com/registerteacher.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(15000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getQuery(param));
                writer.flush();
                writer.close();
                os.close();
                urlConnection.connect();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String result = convertInputStreamToString(in);
                System.out.println("--------------------------"+result);
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {   progressDialog.dismiss();
            teacherCallback.done(null);
            super.onPostExecute(aVoid);
        }
    }



    public void fetchTeacherDataInBackground(Teacher teacher,GetTeacherCallback teacherCallback)
    {
        progressDialog.show();
        new FetchTeacherDataAsyncTack(teacher,teacherCallback).execute();
    }
    public class FetchTeacherDataAsyncTack extends AsyncTask<Void,Void,Teacher>
    {
        Teacher teacher;
        GetTeacherCallback teacherCallback;
        public  FetchTeacherDataAsyncTack(Teacher teacher,GetTeacherCallback teacherCallback)
        {
            this.teacher=teacher;
            this.teacherCallback=teacherCallback;
        }

        @Override
        protected Teacher doInBackground(Void... params)
        {
            ArrayList<NameValuePair> param=new ArrayList<>();
            param.add(new BasicNameValuePair("username",teacher.username));
            param.add(new BasicNameValuePair("password", teacher.password));
            try {
                URL url = new URL("http://fara.16mb.com/loginteacher.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(15000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getQuery(param));
                writer.flush();
                writer.close();
                os.close();
                urlConnection.connect();
                InputStream in       = new BufferedInputStream(urlConnection.getInputStream());
                String result        = convertInputStreamToString(in);
                System.out.println(result);
                JSONObject jsonObject=new JSONObject(new JSONTokener(result));
                String name          =jsonObject.getString("name");
                String ic              =jsonObject.getString("ic");
                String username      =jsonObject.getString("username");
                String password      =jsonObject.getString("password");
                teacher=new Teacher(name,ic,username,password);
            }catch (Exception e)
            {
                e.printStackTrace();
            }

            return teacher;
        }
        @Override
        protected void onPostExecute(Teacher teacher)
        {   progressDialog.dismiss();
            teacherCallback.done(teacher);
            super.onPostExecute(teacher);
        }
    }


    private static String convertInputStreamToString(InputStream inputStream) throws IOException
    {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;
    }
    private static String getQuery(ArrayList<NameValuePair> params) throws UnsupportedEncodingException
    {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (NameValuePair pair : params)
        {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
        }

        return result.toString();
    }
}



