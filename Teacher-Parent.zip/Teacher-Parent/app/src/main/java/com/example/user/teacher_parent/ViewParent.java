package com.example.user.teacher_parent;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.user.teacher_parent.R;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewParent extends ActionBarActivity {

    private ProgressDialog pDialog;
    String myJSON;

    private static final String TAG_RESULTS="result";
    private static final String TAG_PID = "parent_id";
    private static final String TAG_NAME = "parent_name";
    private static final String TAG_IC ="parent_ic";

    JSONArray parent = null;

    ArrayList<HashMap<String, String>> parentList;

    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_parent);
        list = (ListView) findViewById(R.id.listView);
        parentList = new ArrayList<HashMap<String,String>>();
        getData();
    }


    protected void showList(){
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            parent = jsonObj.getJSONArray(TAG_RESULTS);

            for(int i=0;i<parent.length();i++){
                JSONObject c = parent.getJSONObject(i);
                String parent_id = c.getString(TAG_PID);
                String parent_name = c.getString(TAG_NAME);
                String parent_ic = c.getString(TAG_IC);

                HashMap<String,String> parent = new HashMap<String,String>();

                parent.put(TAG_PID,parent_id);
                parent.put(TAG_NAME,parent_name);
                parent.put(TAG_IC,parent_ic);

                parentList.add(parent);
            }

            ListAdapter adapter = new SimpleAdapter(
                    ViewParent.this, parentList, R.layout.activity_list_parent,
                    new String[]{TAG_PID,TAG_NAME,TAG_IC},
                    new int[]{R.id.pid, R.id.name, R.id.ic}
            );

            list.setAdapter(adapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public void getData(){
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(ViewParent.this);
                pDialog.setMessage("Loading..");
                pDialog.setIndeterminate(false);
                pDialog.setCancelable(true);
                pDialog.show();
            }
            @Override
            protected String doInBackground(String... params) {
                DefaultHttpClient httpclient = new DefaultHttpClient(new BasicHttpParams());
                HttpPost httppost = new HttpPost("http://fara.16mb.com/getParent.php");

                // Depends on your web service
                httppost.setHeader("Content-type", "application/json");

                InputStream inputStream = null;
                String result = null;
                try {
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity entity = response.getEntity();

                    inputStream = entity.getContent();
                    // json is UTF-8 by default
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
                    StringBuilder sb = new StringBuilder();

                    String line = null;
                    while ((line = reader.readLine()) != null)
                    {
                        sb.append(line + "\n");
                    }
                    result = sb.toString();
                } catch (Exception e) {
                    // Oops
                }
                finally {
                    try{if(inputStream != null)inputStream.close();}catch(Exception squish){}
                }
                return result;
            }

            @Override
            protected void onPostExecute(String result){
                pDialog.dismiss();
                myJSON=result;
                showList();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }

}