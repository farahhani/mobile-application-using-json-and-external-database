package com.example.user.teacher_parent;

import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class RegisterParent extends ActionBarActivity
{
    EditText etName,etIC,etUsername,etPassword;
    Button bRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_parent);

        etName=(EditText)findViewById(R.id.etName);
        etIC=(EditText)findViewById(R.id.etIC);
        etUsername=(EditText)findViewById(R.id.etUsername);
        etPassword=(EditText)findViewById(R.id.etPassword);
        bRegister=(Button)findViewById(R.id.bRegister);
    }
    public void onClickRegister(View view)
    {
        String name     = etName.getText().toString();
        String ic     = etIC.getText().toString();
        String username = etUsername.getText().toString();
        String password = etPassword.getText().toString();


        if(name.equals("") || ic.equals("") || username.equals("") || password.equals("")){

            Toast.makeText(RegisterParent.this, "The text must be filled", Toast.LENGTH_SHORT).show();

            return;

        }
        else
        {
            Parent parent       =new Parent(name,ic,username,password);
            registerParent(parent);
        }
    }
    public void registerParent(Parent parent)
    {
        ServerRequestParent serverRequest=new ServerRequestParent(this);
        serverRequest.storeParentDataInBackground(parent, new GetParentCallback() {
            @Override
            public void done(Parent parent) {
                Intent intent = new Intent(getApplicationContext(), Welcome.class);
                Toast.makeText(RegisterParent.this, "Success", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });
    }

}