package com.example.user.teacher_parent;

/**
 * Created by user on 1/11/2015.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class UserLocalStore
{
    public static final String SP_User="user";
    SharedPreferences userLocalDatabase;
    public UserLocalStore(Context context)
    {
        userLocalDatabase=context.getSharedPreferences(SP_User,0);
    }
    public void storeUserData(User user)
    {
        SharedPreferences.Editor spEditor=userLocalDatabase.edit();
        spEditor.putString("name",user.name);
        spEditor.putString("ic", user.ic);
        spEditor.putString("username",user.username);
        spEditor.putString("password",user.password);
        spEditor.commit();
    }
    public User getLoggedInUser()
    {
        String name     =userLocalDatabase.getString("name", "");
        String ic         =userLocalDatabase.getString("ic", "");
        String username =userLocalDatabase.getString("username", "");
        String password =userLocalDatabase.getString("password","");
        User user       =new User(name,ic,username,password);
        return user;
    }
    public  void setUserLoggedIn(boolean loggedIn)
    {
        SharedPreferences.Editor spEditor=userLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }
    public void  clearUserData()
    {
        SharedPreferences.Editor spEditor=userLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }
    public boolean getUserLoggedIn()
    {
        if (userLocalDatabase.getBoolean("loggedIn", false)== true)
        {
            return true;
        }else{
            return false;
        }
    }
}
