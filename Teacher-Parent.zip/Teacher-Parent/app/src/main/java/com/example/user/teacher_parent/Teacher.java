package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
public class Teacher
{
    String name,username,password,ic;

    public Teacher(String name,String ic,String username,String password)
    {
        this.name=name;
        this.ic=ic;
        this.username=username;
        this.password=password;
    }
    public Teacher(String username,String password)
    {
        this.name="";
        this.ic="";
        this.username=username;
        this.password=password;
    }
}