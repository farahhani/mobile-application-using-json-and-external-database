package com.example.user.teacher_parent;

/**
 * Created by user on 20/11/2015.
 */
public class Parent
{
    String name,ic,username,password;

    public Parent(String name,String ic,String username,String password)
    {
        this.name=name;
        this.ic=ic;
        this.username=username;
        this.password=password;
    }
    public Parent(String username,String password)
    {
        this.name="";
        this.ic="";
        this.username=username;
        this.password=password;
    }
}
