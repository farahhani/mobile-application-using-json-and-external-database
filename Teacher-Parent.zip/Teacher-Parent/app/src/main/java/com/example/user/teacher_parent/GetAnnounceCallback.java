package com.example.user.teacher_parent;

/**
 * Created by user on 21/11/2015.
 */
interface GetAnnounceCallback
{
    public abstract void done(Announcement ann);
}
