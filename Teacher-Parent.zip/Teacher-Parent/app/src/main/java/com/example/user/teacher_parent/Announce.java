package com.example.user.teacher_parent;

import android.content.Intent;
import android.os.Bundle;

import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Announce extends ActionBarActivity
{
    EditText etDate,etEvent;
    Button bAdd, bView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announce);

        etDate=(EditText)findViewById(R.id.etDate);
        etEvent=(EditText)findViewById(R.id.etEvent);

        bAdd=(Button)findViewById(R.id.bAdd);
        bView=(Button)findViewById(R.id.bView);
    }
    public void onClickRegister(View view)
    {
        String date     = etDate.getText().toString();
        String event = etEvent.getText().toString();

        if(date.equals("") || event.equals("") ){

            Toast.makeText(Announce.this, "Date and Event must be filled", Toast.LENGTH_SHORT).show();

            return;

        }
        else {
            Announcement announcement = new Announcement(date, event);
            registerAnnounce(announcement);
        }
    }
    public void onClickView(View view)
    {
        Intent intent = new Intent(getApplicationContext(), ViewAnnounce.class);
        startActivity(intent);
    }
    public void registerAnnounce(Announcement announcement)
    {
        ServerRequestAnnouncement serverRequestAnnouncement=new ServerRequestAnnouncement(this);
        serverRequestAnnouncement.storeAnnouncementDataInBackground(announcement, new GetAnnounceCallback() {
            @Override
            public void done(Announcement announcement) {
                Intent intent = new Intent(getApplicationContext(), Announce.class);
                Toast.makeText(Announce.this, "Added", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });
    }
}