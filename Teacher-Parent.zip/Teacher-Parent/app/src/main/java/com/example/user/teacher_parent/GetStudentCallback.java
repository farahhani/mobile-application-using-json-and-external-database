package com.example.user.teacher_parent;

/**
 * Created by user on 20/11/2015.
 */
interface GetStudentCallback
{
    public abstract void done(Student student);
}
