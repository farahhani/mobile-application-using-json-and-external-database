package com.example.user.teacher_parent;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class Add extends ActionBarActivity implements View.OnClickListener {

    Button bLogout,bRegStudent, bRegParent;
    TeacherLocalStore teacherLocalStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        bLogout = (Button) findViewById(R.id.bLogout);
        bRegStudent = (Button) findViewById(R.id.bRegStudent);
        bRegParent = (Button) findViewById(R.id.bRegParent);

        bLogout.setOnClickListener(this);
        bRegParent.setOnClickListener(this);
        bRegStudent.setOnClickListener(this);

        teacherLocalStore = new TeacherLocalStore(this);

    }
    @Override

    public void onClick(View v){

        switch (v.getId()){
            case R.id.bLogout:

                Intent loginscreen=new Intent(this,MainActivity.class);
                loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
                startActivity(loginscreen);
                this.finish();
                break;

            case R.id.bRegStudent:
                startActivity(new Intent(this, RegisterStudent.class));
                break;

            case R.id.bRegParent:
                startActivity(new Intent(this, RegisterParent.class));
                break;


        }
    }


}

