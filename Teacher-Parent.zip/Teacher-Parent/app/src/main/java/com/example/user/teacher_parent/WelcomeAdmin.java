package com.example.user.teacher_parent;

import android.app.ActionBar;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class WelcomeAdmin extends ActionBarActivity implements View.OnClickListener {

    Button bT, bRecord, bLogout;
    EditText etName;
    UserLocalStore userLocalStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_admin);

        etName = (EditText) findViewById(R.id.etName);
        bT = (Button) findViewById(R.id.bT);
        bLogout = (Button) findViewById(R.id.bLogout);
        bRecord = (Button) findViewById(R.id.bRecord);

        bLogout.setOnClickListener(this);
       bT.setOnClickListener(this);
        bRecord.setOnClickListener(this);

        userLocalStore = new UserLocalStore(this);
    }

    @Override

    public void onClick(View v){

        switch (v.getId()){
            case R.id.bLogout:
                Intent loginscreen=new Intent(this,MainActivity.class);
                loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
                startActivity(loginscreen);
                this.finish();
                break;

            case R.id.bT:
                startActivity(new Intent(this, AdminTeacher.class));
                break;

            case R.id.bRecord:
                startActivity(new Intent(this, AdminRecord.class));
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_welcome_admin, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.list_item) {
            return true;}
        else if (id == R.id.menu_profile) {
            goToMenuProfilePage();
            return true;
        }else if (id == R.id.menu_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goToMenuProfilePage()
    {
        Intent intent = new Intent(this,Profile.class);
        startActivity(intent);
    }

    private void logout()
    {
        Intent loginscreen=new Intent(this,MainActivity.class);
        loginscreen.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Toast.makeText(this, "WELCOME TO LOGINSCREEN", Toast.LENGTH_SHORT).show();
        startActivity(loginscreen);
        this.finish();
    }


}

