package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
import android.content.Context;
import android.content.SharedPreferences;

public class ParentLocalStore
{
    public static final String SP_Parent="parent";
    SharedPreferences parentLocalDatabase;
    public ParentLocalStore(Context context)
    {
        parentLocalDatabase=context.getSharedPreferences(SP_Parent,0);
    }
    public void storeParentData(Parent parent)
    {
        SharedPreferences.Editor spEditor=parentLocalDatabase.edit();
        spEditor.putString("name",parent.name);
        spEditor.putString("ic", parent.ic);
        spEditor.putString("username",parent.username);
        spEditor.putString("password",parent.password);
        spEditor.commit();
    }
    public Parent getLoggedInParent()
    {
        String name     =parentLocalDatabase.getString("name", "");
        String ic         =parentLocalDatabase.getString("ic", "");
        String username =parentLocalDatabase.getString("username", "");
        String password =parentLocalDatabase.getString("password","");
        Parent parent       =new Parent(name,ic,username,password);
        return parent;
    }
    public  void setParentLoggedIn(boolean loggedIn)
    {
        SharedPreferences.Editor spEditor=parentLocalDatabase.edit();
        spEditor.putBoolean("loggedIn",loggedIn);
        spEditor.commit();
    }
    public void  clearParentData()
    {
        SharedPreferences.Editor spEditor=parentLocalDatabase.edit();
        spEditor.clear();
        spEditor.commit();
    }
    public boolean getParentLoggedIn()
    {
        if (parentLocalDatabase.getBoolean("loggedIn", false)== true)
        {
            return true;
        }else{
            return false;
        }
    }
}

