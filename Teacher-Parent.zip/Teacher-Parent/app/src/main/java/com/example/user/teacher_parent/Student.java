package com.example.user.teacher_parent;

/**
 * Created by user on 20/11/2015.
 */
public class Student
{
    String name, cls,ic, mark, comment;

    public Student(String name,String ic,String cls,String mark,String comment)
    {
        this.name=name;
        this.ic=ic;
        this.cls=cls;
        this.mark=mark;
        this.comment=comment;

    }
}
