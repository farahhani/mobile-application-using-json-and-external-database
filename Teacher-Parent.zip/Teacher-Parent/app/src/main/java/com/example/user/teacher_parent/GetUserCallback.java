package com.example.user.teacher_parent;

/**
 * Created by user on 1/11/2015.
 */
interface GetUserCallback
{
    public abstract void done(User returnedUser);
}
