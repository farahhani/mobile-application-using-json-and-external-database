
package com.example.user.teacher_parent;

/**
 * Created by user on 1/11/2015.
 */
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;


public class ServerRequestParent
{
    ProgressDialog progressDialog;
    public ServerRequestParent(Context context) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setCancelable(false);
        progressDialog.setTitle("Processing");
        progressDialog.setMessage("Please wait....");
        System.out.println("--------------------------");
    }

    public void storeParentDataInBackground(Parent parent, GetParentCallback parentCallback)
    {
        progressDialog.show();
        new StoreParentDataAsyncTack(parent,parentCallback).execute();
    }
    public class StoreParentDataAsyncTack extends AsyncTask<Void,Void,Void>
    {
        Parent parent;
        GetParentCallback parentCallback;
        public  StoreParentDataAsyncTack(Parent parent,GetParentCallback parentCallback)
        {
            this.parent=parent;
            this.parentCallback= parentCallback;
        }

        @Override
        protected Void doInBackground(Void... params)
        {
            ArrayList<NameValuePair> param=new ArrayList<>();
            param.add(new BasicNameValuePair("name",parent.name));
            param.add(new BasicNameValuePair("ic",parent.ic));
            param.add(new BasicNameValuePair("username",parent.username));
            param.add(new BasicNameValuePair("password", parent.password));
            try {
                URL url = new URL("http://fara.16mb.com/registerparent.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(15000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getQuery(param));
                writer.flush();
                writer.close();
                os.close();
                urlConnection.connect();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String result = convertInputStreamToString(in);
                System.out.println("--------------------------"+result);
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {   progressDialog.dismiss();
            parentCallback.done(null);
            super.onPostExecute(aVoid);
        }
    }



    public void fetchParentDataInBackground(Parent parent,GetParentCallback parentCallback)
    {
        progressDialog.show();
        new FetchParentDataAsyncTack(parent,parentCallback).execute();
    }
    public class FetchParentDataAsyncTack extends AsyncTask<Void,Void,Parent>
    {
        Parent parent;
        GetParentCallback parentCallback;
        public  FetchParentDataAsyncTack(Parent parent,GetParentCallback parentCallback)
        {
            this.parent=parent;
            this.parentCallback=parentCallback;
        }

        @Override
        protected Parent doInBackground(Void... params)
        {
            ArrayList<NameValuePair> param=new ArrayList<>();
            param.add(new BasicNameValuePair("username",parent.username));
            param.add(new BasicNameValuePair("password", parent.password));
            try {
                URL url = new URL("http://fara.16mb.com/loginparent.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setReadTimeout(15000);
                urlConnection.setConnectTimeout(15000);
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoInput(true);
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(getQuery(param));
                writer.flush();
                writer.close();
                os.close();
                urlConnection.connect();
                InputStream in       = new BufferedInputStream(urlConnection.getInputStream());
                String result        = convertInputStreamToString(in);
                System.out.println(result);
                JSONObject jsonObject=new JSONObject(new JSONTokener(result));
                String name          =jsonObject.getString("name");
                String ic              =jsonObject.getString("ic");
                String username      =jsonObject.getString("username");
                String password      =jsonObject.getString("password");
                parent=new Parent(name,ic,username,password);
            }catch (Exception e)
            {
                e.printStackTrace();
            }

            return parent;
        }
        @Override
        protected void onPostExecute(Parent parent)
        {   progressDialog.dismiss();
            parentCallback.done(parent);
            super.onPostExecute(parent);
        }
    }


    private static String convertInputStreamToString(InputStream inputStream) throws IOException
    {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;
    }
    private static String getQuery(ArrayList<NameValuePair> params) throws UnsupportedEncodingException
    {
        StringBuilder result = new StringBuilder();
        boolean first = true;

        for (NameValuePair pair : params)
        {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
        }

        return result.toString();
    }
}




