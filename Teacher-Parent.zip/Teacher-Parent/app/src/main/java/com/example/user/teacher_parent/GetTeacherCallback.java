package com.example.user.teacher_parent;

/**
 * Created by user on 16/11/2015.
 */
interface GetTeacherCallback
{
    public abstract void done(Teacher teacher);
}
