package com.example.user.teacher_parent;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends ActionBarActivity implements View.OnClickListener {
    Button bTeacher,bAdmin,bParent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        bTeacher = (Button) findViewById(R.id.bTeacher);
        bAdmin = (Button) findViewById(R.id.bAdmin);
        bParent = (Button) findViewById(R.id.bParent);

        bTeacher.setOnClickListener(this);
        bAdmin.setOnClickListener(this);
        bParent.setOnClickListener(this);
    }

    public void onClick(View v){

        switch (v.getId()){

            case R.id.bTeacher:
                Intent intent = new Intent(getApplicationContext(),
                        Login_teacher.class);
                startActivity(intent);
                break;

            case R.id.bParent:
                Intent intnt = new Intent(getApplicationContext(),
                        Login_parent.class);
                startActivity(intnt);
                break;

            case R.id.bAdmin:
                Intent intt = new Intent(getApplicationContext(),
                        Login_admin.class);
                startActivity(intt);
                break;

        }
    }

}